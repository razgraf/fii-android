package ro.vansoftware.onlineshop.storage;

import android.content.Context;
import android.content.SharedPreferences;

public class Shared {

    private final String STORAGE = "STORAGE";

    public static final String USER_USERNAME = "USER_USERNAME";
    public static final String USER_PASSWORD = "USER_PASSWORD";

    public static SharedPreferences instance;

    public Shared(Context context){
        if(instance == null) instance = context.getSharedPreferences(STORAGE, Context.MODE_PRIVATE);
    }

    public static void set(Context context, String key, String value){
        SharedPreferences.Editor editor  = instance.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String get(Context context, String key){
        return instance.getString(key, null);
    }
}
